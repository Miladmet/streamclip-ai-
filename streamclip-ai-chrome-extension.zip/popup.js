// StreamClip AI - Popup Controller

document.addEventListener('DOMContentLoaded', async () => {
  const activeChannelLabel = document.getElementById('activeChannelLabel');
  const openStudioBtn = document.getElementById('openStudioBtn');
  const connectStreamBtn = document.getElementById('connectStreamBtn');
  const streamStatusBadge = document.getElementById('streamStatusBadge');
  const clipBtn = document.getElementById('clipBtn');
  const layoutSelect = document.getElementById('layoutSelect');
  const panX = document.getElementById('panX');
  const panXVal = document.getElementById('panXVal');
  const panY = document.getElementById('panY');
  const panYVal = document.getElementById('panYVal');
  const zoom = document.getElementById('zoom');
  const zoomVal = document.getElementById('zoomVal');
  const fitTwitchBtn = document.getElementById('fitTwitchBtn');
  const hookInput = document.getElementById('hookInput');
  const copyTitleBtn = document.getElementById('copyTitleBtn');
  const titleSug = document.getElementById('titleSug');
  const vaultList = document.getElementById('vaultList');

  // Open Full Screen Live Studio
  openStudioBtn.addEventListener('click', () => {
    chrome.tabs.create({ url: chrome.runtime.getURL('studio.html') });
  });

  // Load stored state
  const state = await chrome.storage.local.get([
    'activeChannel',
    'currentLayout',
    'panX',
    'panY',
    'zoom',
    'vault',
    'isStreamConnected'
  ]);

  if (state.activeChannel) activeChannelLabel.textContent = `@${state.activeChannel}`;
  if (state.currentLayout) layoutSelect.value = state.currentLayout;
  if (state.panX !== undefined) {
    panX.value = state.panX;
    panXVal.textContent = `${state.panX}%`;
  }
  if (state.panY !== undefined) {
    panY.value = state.panY;
    panYVal.textContent = `${state.panY}%`;
  }
  if (state.zoom !== undefined) {
    zoom.value = Math.round(state.zoom * 10);
    zoomVal.textContent = `${state.zoom.toFixed(1)}x`;
  }

  if (state.isStreamConnected) {
    connectStreamBtn.innerHTML = '<span>✅ Live Tab Connected!</span>';
    connectStreamBtn.style.background = 'rgba(16, 185, 129, 0.4)';
    streamStatusBadge.textContent = 'Mode: 🔴 Live Video Stream Active';
    streamStatusBadge.style.color = '#10b981';
  }

  renderVault(state.vault || []);

  // Connect active stream tab (YouTube or Twitch)
  connectStreamBtn.addEventListener('click', async () => {
    connectStreamBtn.disabled = true;
    connectStreamBtn.innerHTML = '<span>🎥 Connecting Stream Tab...</span>';

    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab) {
        alert('Please open your YouTube or Twitch video tab first.');
        resetConnectBtn();
        return;
      }

      // Detect title / channel name
      try {
        const url = new URL(tab.url);
        if (url.hostname.includes('youtube.com')) {
          const rawTitle = (tab.title || 'YouTube').split('-')[0].trim();
          const cleanName = rawTitle.replace(/[^a-zA-Z0-9_ ]/g, '').trim().substring(0, 16) || 'YouTube';
          activeChannelLabel.textContent = `@${cleanName}`;
          chrome.storage.local.set({ activeChannel: cleanName });
        } else if (url.hostname.includes('twitch.tv')) {
          const parts = url.pathname.split('/').filter(Boolean);
          if (parts.length > 0) {
            const ch = parts[0];
            activeChannelLabel.textContent = `@${ch}`;
            chrome.storage.local.set({ activeChannel: ch });
          }
        }
      } catch (e) {}

      const streamId = await chrome.tabCapture.getMediaStreamId({ targetTabId: tab.id });

      chrome.runtime.sendMessage({
        target: 'offscreen',
        action: 'CONNECT_STREAM',
        streamId: streamId
      }, (res) => {
        connectStreamBtn.disabled = false;
        if (res && res.success) {
          connectStreamBtn.innerHTML = '<span>✅ Live Tab Connected!</span>';
          connectStreamBtn.style.background = 'rgba(16, 185, 129, 0.4)';
          streamStatusBadge.textContent = 'Mode: 🔴 Live Video Stream Active';
          streamStatusBadge.style.color = '#10b981';
          chrome.storage.local.set({ isStreamConnected: true });
        } else {
          resetConnectBtn();
          alert('Could not capture stream: ' + (res?.error || 'Unknown error'));
        }
      });
    } catch (err) {
      resetConnectBtn();
      alert('Tab capture permission error: ' + err.message);
    }
  });

  function resetConnectBtn() {
    connectStreamBtn.disabled = false;
    connectStreamBtn.innerHTML = '<span>🎥 Connect Live Stream Tab</span>';
    connectStreamBtn.style.background = 'rgba(16, 185, 129, 0.15)';
  }

  function syncConfig() {
    const config = {
      layout: layoutSelect.value,
      panX: parseInt(panX.value, 10),
      panY: parseInt(panY.value, 10),
      zoom: parseInt(zoom.value, 10) / 10,
      hookBanner: hookInput.value
    };

    chrome.storage.local.set({
      currentLayout: config.layout,
      panX: config.panX,
      panY: config.panY,
      zoom: config.zoom
    });

    chrome.runtime.sendMessage({
      target: 'offscreen',
      action: 'SET_CONFIG',
      ...config
    });
  }

  layoutSelect.addEventListener('change', syncConfig);
  panX.addEventListener('input', () => {
    panXVal.textContent = `${panX.value}%`;
    syncConfig();
  });
  panY.addEventListener('input', () => {
    panYVal.textContent = `${panY.value}%`;
    syncConfig();
  });
  zoom.addEventListener('input', () => {
    zoomVal.textContent = `${(zoom.value / 10).toFixed(1)}x`;
    syncConfig();
  });
  hookInput.addEventListener('input', syncConfig);

  fitTwitchBtn.addEventListener('click', () => {
    panX.value = 28;
    panXVal.textContent = '28%';
    panY.value = 34;
    panYVal.textContent = '34%';
    zoom.value = 15;
    zoomVal.textContent = '1.5x';
    syncConfig();
  });

  clipBtn.addEventListener('click', () => {
    clipBtn.disabled = true;
    clipBtn.innerHTML = '<span>⚡ Slicing last 30s WebM...</span>';

    const channel = activeChannelLabel.textContent.replace('@', '');

    chrome.runtime.sendMessage({
      action: 'CAPTURE_CLIP',
      channel: channel,
      clipper: 'Popup'
    }, (res) => {
      clipBtn.disabled = false;
      clipBtn.innerHTML = '<span>⚡ Slice Last 30s (9:16 WebM)</span>';

      if (res && res.success) {
        chrome.storage.local.get(['vault'], (d) => {
          renderVault(d.vault || []);
        });
      } else {
        alert(res?.error || 'Could not export clip.');
      }
    });
  });

  copyTitleBtn.addEventListener('click', () => {
    navigator.clipboard.writeText(titleSug.textContent);
    copyTitleBtn.textContent = 'Copied!';
    setTimeout(() => { copyTitleBtn.textContent = 'Copy'; }, 1500);
  });

  function renderVault(vault) {
    vaultList.innerHTML = '';
    if (!vault.length) {
      const emptyDiv = document.createElement('div');
      emptyDiv.style.cssText = 'font-size:11px; color:var(--muted); text-align:center; padding:6px;';
      emptyDiv.textContent = 'No clips captured yet.';
      vaultList.appendChild(emptyDiv);
      return;
    }

    vault.forEach(clip => {
      const item = document.createElement('div');
      item.className = 'vault-item';

      const infoDiv = document.createElement('div');
      const strong = document.createElement('strong');
      strong.textContent = clip.channel || 'streamer';
      infoDiv.appendChild(strong);

      const timeSpan = document.createElement('span');
      timeSpan.textContent = ` (${clip.timestamp || ''}) `;
      infoDiv.appendChild(timeSpan);

      const sizeSpan = document.createElement('span');
      sizeSpan.style.cssText = 'color:var(--muted); font-size:10px;';
      sizeSpan.textContent = clip.size || '';
      infoDiv.appendChild(sizeSpan);

      const link = document.createElement('a');
      link.href = clip.blobUrl || '#';
      link.download = `StreamClip_${(clip.channel || 'clip').replace(/[^a-zA-Z0-9_-]/g, '_')}_${clip.id || Date.now()}.webm`;
      link.textContent = 'Download';

      item.appendChild(infoDiv);
      item.appendChild(link);
      vaultList.appendChild(item);
    });
  }
});
